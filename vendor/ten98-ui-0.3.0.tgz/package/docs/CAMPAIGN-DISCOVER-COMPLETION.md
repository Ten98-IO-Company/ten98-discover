# Campaign and Discover UI completion ledger

Understood as: complete the missing shared UI and reference flows for Campaign C1–C8 and Discover D1–D17 from the reviewed research, then coordinate each consuming app's integration without replacing its controllers, persistence, permissions or existing behavior. The owner's latest request authorizes this UI implementation wave; paid/provider operations remain excluded from validation.

The coordinator owns this ledger, shared CSS/barrels, package versions, browser acceptance and publishing. Each bounded worker owns named files and must stop at its assigned gate. App sessions own their integration and real regression checks. Research-only new backend/features are not silently enabled by a catalogue preview.

## Completion gates

For each row: inspect real consumer contract → build or reuse typed presentation → complete interactive catalogue flow and applicable states → compile/test/browser acceptance → app integration plus preserved behavior evidence. A row is complete only when its required gates pass. A blocked API is recorded specifically; no fallback result may be labelled implemented.

| Flow | Task | Shared presentation / current work | Catalogue + checks | Consumer integration |
| --- | --- | --- | --- | --- |
| C1 | Compose and validate a social post | Contract inventory / bounded component wave underway | Pending | App session mapping |
| C2 | Plan a calendar and approve content | Contract inventory / bounded component wave underway | Pending | App session mapping |
| C3 | Create and activate a paid campaign | Contract inventory / bounded component wave underway | Pending | App session mapping |
| C4 | Inspect performance and review paid changes | Contract inventory / bounded component wave underway | Pending | App session mapping |
| C5 | Plan, book and reconcile OOH placements | Contract inventory / bounded component wave underway | Pending | App session mapping |
| C6 | Publishing recovery and unified inbox | Contract inventory / bounded component wave underway | Pending | App session mapping |
| C7 | Find, approve and attach media | Contract inventory / bounded component wave underway | Pending | App session mapping |
| C8 | Direct campaign audience, preview and send | Contract inventory / bounded component wave underway | Pending | App session mapping |
| D1 | Website installation to first useful report | Contract inventory / bounded component wave underway | Pending | App session mapping |
| D2 | Overview, filter and comparison | Contract inventory / bounded component wave underway | Pending | App session mapping |
| D3 | Query explorer and breakdown | Contract inventory / bounded component wave underway | Pending | App session mapping |
| D4 | Goals and funnels | Contract inventory / bounded component wave underway | Pending | App session mapping |
| D5 | Retention and journeys | Contract inventory / bounded component wave underway | Pending | App session mapping |
| D6 | Attribution and campaign measurement | Contract inventory / bounded component wave underway | Pending | App session mapping |
| D7 | Heatmap investigation | Contract inventory / bounded component wave underway | Pending | App session mapping |
| D8 | Replay investigation | Contract inventory / bounded component wave underway | Pending | App session mapping |
| D9 | Build and share reports | Contract inventory / bounded component wave underway | Pending | App session mapping |
| D10 | Measurement confidence across reports | Contract inventory / bounded component wave underway | Pending | App session mapping |
| D11 | Keyword exploration and saved research | Contract inventory / bounded component wave underway | Pending | App session mapping |
| D12 | Domain/backlink research and charged-run review | Contract inventory / bounded component wave underway | Pending | App session mapping |
| D13 | Project setup and rank history | Contract inventory / bounded component wave underway | Pending | App session mapping |
| D14 | Technical site audit | Contract inventory / bounded component wave underway | Pending | App session mapping |
| D15 | Owned-property search performance | Contract inventory / bounded component wave underway | Pending | App session mapping |
| D16 | AI prompt setup, execution and comparisons | Contract inventory / bounded component wave underway | Pending | App session mapping |
| D17 | Citation and answer investigation | Contract inventory / bounded component wave underway | Pending | App session mapping |

## Confirmed invariants

- Existing Campaign/Discover logo, icons, split login composition, native forms and controllers remain authoritative.
- New surfaces use scoped `t98-` rules; no global reset, app theme change or uncontrolled-select substitution.
- Campaign retains per-account variants, immutable account currency/budget types, create-paused/readback/explicit activation, OOH provider limits, upload recovery, send receipts and safe unsaved-draft guards.
- Discover retains applied-query/counting units, null-versus-zero, consent/capture isolation, measurement evidence, usage accounting and paused paid operations.
- Draft, submitted, accepted, delivered and observed outcomes remain distinct. Unknown mutation outcomes require app-owned reconciliation before repeat.
- Every released archive stays immutable; app integrations pin the same new archive and keep manifest/lockfile/vendor inputs together.
