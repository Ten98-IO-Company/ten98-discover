# Release validation

## Metric readability, error alerts and Settings reflow: 0.3.9

The complete `npm run check:all` gate passes: **58 native checks, 510 strict standalone TSX examples and 156 Playwright cases**. Coverage remains 73 components, 405 states and 28 flows. Public APIs, declarations, app tokens and compatibility JavaScript remain unchanged.

ComparisonMetric uses intrinsic, text-relative tracks and supporting typography only for true missing values. Four browser cases cover 260px desktop panels and 320px viewports in light/dark, normal/actual doubled text, complete words, formatted baseline, zero, reasons and source context. Restoring the old grid and metric styling reproduces fragmentation. ReportPanel errors use one alert; other states keep a polite status. Native checks cover all eight states; two browser cases exercise ready/error/ready transitions, the retained payload and an unaffected sibling. The old implementation fails the same alert assertion in both projects. Access and expiry rules remain unchanged.

Actual Campaign Settings exposed a 752px document at a 320px viewport. One direct-grid-child minimum-width guard retains the desktop tracks and existing table scroller. Two native-markup browser cases check normal/actual doubled text, document/column/control bounds, complete table headers/row/action, table-owned scrolling and native form values. Restoring the old minimum reproduces overflow at both text sizes. The [consumer recheck](reviews/2026-10-19/consumer-screens.md#settings-and-exact-price-review--later-frozen-038-fixture) verifies Campaign's identical temporary bridge; package adoption remains a separate gate.

The template comparison link follows the working preview, preserving the existing narrow first-screen and keyboard checks. Independent read-only implementation/oracle reviews found no actionable blockers. One earlier full attempt loaded blank pages because React dependency requests returned Vite `504 Outdated Optimize Dep`; it was stopped. The verified catalogue server was restarted with a fresh cache, after which the unchanged 154-case checkpoint passed; the final Settings-inclusive gate passes all 156 cases. No assertion or timeout was weakened to obtain that result.

## Screenshot comparison navigation

The catalogue flow index, individual Campaign/Discover recipes, cross-product recipes and template guide link to the retained product-UI comparison reports. A focused Playwright check passes ten desktop/320px cases for exact destinations, accessible link names, keyboard focus and page containment, with no page errors. Typecheck and the production catalogue/library build pass. This source-only navigation update changes no library API or immutable 0.3.8 archive.

## Shared topbar text reflow: 0.3.8

The full `npm run check:all` gate passes: 58 native checks, 510 strict standalone TSX examples and 148 Playwright cases. Coverage remains 73 components, 405 states and 28 flows. Fixed compatibility header heights become matching 69/60/58px minimums; the breadcrumb can shrink and wrap without hiding context. APIs, JavaScript, primary actions and page-heading geometry are unchanged.

Actual Campaign 0.3.7 at 320px and verified 2× text had no escaping content controls, but its breadcrumb/profile region widened the document to 382px. A browser-only adaptive-header diagnostic restored a 320px document with no escaping elements. The shared fixture now includes native menu/context/profile markup. Its new cases preserve normal wide/narrow heights, snapshot all relevant computed fonts and line heights before doubling, verify exact heading enlargement and full horizontal/vertical containment, and retain viewport/scale/body/root zoom at 1. Restoring only fixed mobile height and nowrap constraints reproduces overflow. The focused 16-case gate and full suite pass; independent source/oracle review found no actionable blockers. Final actual-consumer re-capture follows adoption.

The rebuilt Campaign 0.3.8 re-capture passes at 1440/320px and exact 2× text: document/client width 320px, title 22→44px, body zoom 1 and no horizontally escaping content buttons/inputs. A measured header audit verifies growth from 58→72px with menu/profile controls contained. It isolated a native fixed-offset skip-link leak and unpaired preview/composer colors, subsequently repaired in Campaign's 793-check checkpoint. Independent final acceptance checks 15 text pairs per actual light/dark CSS theme (minimum 5.156:1/6.457:1), actual composer text doubling from 13→26px with horizontally contained controls, and normal/doubled skip-link hide/focus/Enter behavior. Old pale-surface and fixed-offset negative controls reproduce the original failures. See the [consumer screen review](reviews/2026-10-19/consumer-screens.md) for captured before/after evidence and fixture limits.

The Researcher addition now has a bounded primary-source flow proposal and user-review limitations. It introduces no component API, backend, approved feature, popularity ranking or market-share claim. Screenshots remain separate comparative evidence for the implemented Campaign/Discover flows.

The inspected immutable 0.3.8 archive SHA256 is `516B3C91749011DC489219EE073E8B2239BE2F83ECC05521A41019A6BF74660A`, with 81 entries and a size of 305,040 bytes. All 30 JavaScript/declaration files match 0.3.7 byte-for-byte. Version, MIT license, all three header minimums, breadcrumb wrapping and 40 Markdown files are verified. Images remain excluded; earlier archives remain unchanged.

## Legacy action and navigation themes: 0.3.7

The full `npm run check:all` gate passes: 58 native checks, 510 strict standalone TSX examples and 146 Playwright cases. Coverage remains 73 components, 405 states and 28 flows. This CSS-only correction applies existing semantic text, control-border, subtle-surface, danger and accent roles to compatibility action/navigation states. Geometry, primary/disabled behavior, component APIs and JavaScript are unchanged.

The existing explicit/system theme matrix now measures normal and hovered `.button`/`.btn` actions, primary and danger controls, unselected/selected navigation and counts. It waits for finite CSS transitions before reading actual colors, verifies at least 4.5:1 text contrast, and retains disabled behavior. Restoring the original pale fills independently reproduces selected/count/danger/action-hover/navigation-hover failures. The focused 14-case gate and full suite pass; independent source/oracle review found no actionable problem. These shared checks do not override later application styles. Campaign separately reconciles fixed native foreground overrides observed in its actual browser capture; consumer adoption and re-capture are separate acceptance steps.

The inspected immutable archive SHA256 is `60D92B668DF7DD04AE3FDD060C553A1080B532FC85773B6078FAA77BEBC307FA`, with 80 entries and a size of 298,144 bytes. All 30 emitted JavaScript/declaration files are byte-identical to 0.3.6. Version, MIT license, semantic action/navigation CSS, 39 Markdown files and image exclusion are verified. Earlier archives remain unchanged.

## Controlled multiline fields: 0.3.6

The complete `npm run check:all` gate passed: 58 native checks, 510 strict standalone TSX examples and 146 Playwright cases. The catalogue has 73 components, 405 states and 28 flows. Literal multiline fields accept native textarea props with correctly typed textarea events; the previous input/dynamic-boolean signature remains available. The input branch is unchanged. Multiline forwarding preserves controlled value/change, read-only state, ID, ARIA and sizing while omitting input-only attributes. Existing uncontrolled drafts and native validation/submission remain intact.

Campaign independently reproduced the failure at the actual native child: typed article HTML changed the DOM but review retained the old controller value, and asynchronous content did not prefill. No article save was sent during the failed check. The shared browser regression holds a synthetic response, verifies the loaded value, edits it, compares exact controller review with native FormData, checks review invalidation and read-only behavior, and preserves uncontrolled user edits after default metadata changes. Required fields are queried by their actual accessible names, including the existing asterisk; component labels were not changed to fit the test. Four focused desktop/narrow cases and the full suite pass. Independent source review and a separate 19-case native library rerun found no blockers. Actual article persistence and final consumer adoption remain app-owned gates.

The inspected immutable archive SHA256 is `3F88760F2A27D46ECFD800C1FA690446155A7A0616D887F54D72EFE2AC16A31F`, with 80 entries and a size of 296,698 bytes. Of 30 emitted JavaScript/declaration files, only `app.js` and `app.d.ts` differ from 0.3.5. Version, MIT license, textarea declaration, documentation inclusion and reference-image exclusion are verified. Earlier archives remain unchanged.

## Design consistency and visual critique: 0.3.5

The full `npm run check:all` gate passed: 57 native checks, 508 standalone strict TSX examples and 142 Playwright cases. Coverage is 73 components, 403 state specimens and 28 flows. A live-inventory comparison verifies a critique entry for every component and flow; the five templates appear in the component count and their dedicated review. See [the exhaustive critique](reviews/2026-10-19/README.md) for findings, baseline screenshots, remedies and direct product comparisons.

New browser cases check table-header and all 19 compatibility-status contrasts in light, dark and system themes; intrinsic specimens and metric token typography; audience summaries constrained inside a desktop panel; template route/focus behavior; list/detail focus and retained drafts; and full-width Explorer/funnel/attribution results. Narrow results retain keyboard-scrollable tables. Restoring the pale status fill and fixed four-column panel reproduces their failures. Actual Campaign screenshots also exposed the pale shared workspace switcher: the existing explicit/system matrix now checks its semantic fill, primary/supporting/avatar contrast, native selection and old-fill negative control. The existing actual-text-doubling, native date-field, modal and complete flow gates still pass.

`VisualEvidenceFrame` adds only optional `rankedListLabel`, preserving exact default headings and region names. New numeric-evidence specimens distinguish coordinate groups and cumulative depth bands from DOM elements; unknown alignment prevents an overlay. Native checks verify escaping and access revocation, and four narrow browser cases verify light/dark labels, copied TSX and unchanged default evidence. Independent source review found no actionable defect in this addition.

Independent read-only review approved the semantic mappings, scoped styles, focus guard and test expectations. The focus fallback preserves initial focus, visible desktop/app focus, guarded selection, app restoration and mounted drafts. This is UI regression evidence; actual consumer adoption, arbitrary theme overrides, assistive-technology certification and live-provider acceptance remain separate.

The immutable 0.3.5 archive SHA256 is `E84AD0F0EF1B27E1494D2191F3097D75EDAD8843A6E2270365355EFC5BD5E2D3`. Inspection verifies 80 entries, 30 JavaScript/declaration files, MIT license and 39 Markdown files. Only coordination and inspection modules/declarations differ from 0.3.4; the coordination declaration change documents focus behavior, and inspection adds the optional label. No reference image is included in the 294,657-byte archive. The 94 screenshots remain in the source repository, with attribution and explicit capture limits. All local review links resolve. A fresh context-free overview review found no surviving comprehension blocker after clarifying shipped fixes, proposals and consumer adoption.

## Native paired-field reflow: 0.3.4

The full `npm run check:all` gate passes: 56 native tests, 507 strict public TSX examples and 118 Playwright cases. The CSS-only patch constrains the shared legacy form tracks and their children, then stacks pairs at viewport widths of 480px or less. JavaScript, declarations, native input markup and field behavior are unchanged.

Ten added browser cases use actual AppField/AppSelect components in a settings panel and native dialog: desktop/320px, light/dark, normal/actual doubled text, and old-rule negative controls. They check visible labels/controls, bounds, narrow stacking, desktop pairing, types, values, constraints, editing, read-only/disabled state and FormData. Restoring the original intrinsic two-column rules reproduces date-grid escape and date-time document overflow. Independent review requested explicit visibility checks; those were added and the focused ten-case gate passed again. Native picker popups, internal segment scrolling and vertical clipping remain outside these geometry checks. Consumer calendar acceptance awaits adoption and its actual-app rerun.

The inspected immutable 0.3.4 archive SHA256 is `E36AB3615FAD0BBEB8CF293A45CAB62CD92C727163B49E11F95E150EA045D2FA`. All 30 JavaScript/declaration files match 0.3.3 byte-for-byte. The package includes the MIT license, correct version and three checked form-grid rules. Both active app owners received this archive and hash for sequential adoption; earlier archives remain unchanged.

## Consumer capability and disabled values: 0.3.3

`npm run check:all` passes: 56 native tests, 507 strict public TSX examples and 108 Playwright cases. The catalogue now has 402 state specimens across the same 73 components and 28 reference flows. The new replay specimens cover an unsupported inactivity preference and a supported read-only preference. Browser checks verify omitted controls, retained play/seek/speed requests, disabled preferences and existing editable checkbox behavior. The native regression also covers both read-only boolean values and a callback without a preference.

The compatibility input uses its semantic disabled-text role even when a consumer supplies an older muted-text override. The light role reuses the established muted palette color, preserving the field's previous contrast; dark keeps its existing disabled-text color. Browser checks measure at least 4.5:1 for these fixture values. Restoring the consumer's inherited purple foreground fails that same dark contrast check. Fresh independent review found no actionable defect in the optional API, copied examples, token change or regression checks. Native player execution and full app acceptance remain app-owned.

The inspected immutable archive SHA256 is `587D396D36E6CD654A6E451F9EB778062267FEC2D96AF90AED6800F1AA8C3B25`. Of 30 emitted JavaScript/declaration files, only `inspection.js` and `inspection.d.ts` differ from 0.3.2. MIT license, version, optional declarations and disabled role CSS are verified. Both active app owners received this exact archive for adoption; prior archives remain unchanged.

Campaign reports verified adoption of that exact archive: sequential offline lock update and clean install, production/type build and 630 passing checks. Its populated disabled field uses the semantic foreground/background in the actual dark app. Discover has reviewed and installed 0.3.3 and accepted the Explorer/Attribution adapters; its replay and full post-adoption gates remain open. Consumer browser evidence is tracked in the [completion ledger](CAMPAIGN-DISCOVER-COMPLETION.md); these checkpoints do not alter the released archive.

## Existing application dark themes: 0.3.2

The full `npm run check:all` gate passes: 55 native tests, 505 strict public TSX examples and 104 Playwright cases. The patch changes two established compatibility fills to existing semantic roles: the translucent topbar uses the surface token, and disabled field inputs use the disabled-surface token. Component APIs, JavaScript, declarations and authentication markup are unchanged.

Twelve added browser cases cover explicit themes overriding the operating system, both system themes, canonical token inheritance, rendered text contrast, native field behavior and light geometry. Restoring only the old fixed light fills reproduces both dark contrast failures. The authentication comparison covers class styling and geometry in a synthetic fixture; complete app screens and product operations remain separate consumer checks. Independent source review found no actionable defect in the scoped patch or checks.

The immutable 0.3.2 archive SHA256 is `A49025981CFF0E1BD4DD936A90B644B437B8120852CA9D012B0D12BD14F45069`. All 30 emitted JavaScript/declaration files are byte-identical to 0.3.1. The inspected package includes the MIT license, current version and corrected compatibility CSS. Both active app owners received this exact archive and hash for adoption.

The source catalogue's setup guide now includes the required browser gate and the full existing-app stylesheet order. Its focused desktop/narrow Playwright cases caught and fixed literal newline escapes in the command snippet, then passed with real multiline values. This catalogue-only follow-up leaves the released archive unchanged.

## Actual text enlargement: 0.3.1

The complete `npm run check:all` gate passes: 55 native tests, 505 strict public TSX examples and 92 Playwright cases. The stronger text test snapshots every computed font size and numeric line height before doubling them, includes isolated app-preview documents, verifies visible headings at exactly 2× and restores styles between hash-route cases. It checks all 73 component state pages at 320px, all 28 flows at desktop and 320px, open modal controls, typed confirmation and focus return. It is text enlargement rather than full page zoom; horizontal reflow is tested, with no blanket certification of all possible clipping or overlap.

This independent validation improvement found nowrap Button labels across multiple patterns. The fix lives once in the shared Button rule: constrained width and wrapping preserve readable labels without changing its API. Catalogue long descriptions/acceptance text and the installation snippet now wrap as well. The original 0.3.0 archive remains immutable. Fresh source review found no further actionable defect in the scoped changes.

The 0.3.1 archive SHA256 is `9F41F5E616E525D70767EDCF138BF6131BC9BC14D86AEA45B8C3A0C3D9C73EB8`. All 30 emitted JavaScript/declaration files are byte-identical to the 0.3.0 archive; the library behavior change is CSS only. Both app owners received this new immutable artifact for the next safe adoption batch.

## Product components, fixed layouts and Playwright: 0.3.0

Validated on 19 October 2026 using Node.js 24, React 19.2.8 and Playwright 1.64.1 with its official Chromium build. `npm run check:all` passed: project typecheck, emitted declarations/modules, catalogue production build, 55 native tests, 505 standalone strict TSX examples and 88 browser cases. The inventory gate covers every public export exactly once: 73 components and 400 state specimens. All C1–C8 and D1–D17 research IDs appear exactly once among 28 interactive flow recipes, each with references and concrete acceptance cases.

Playwright runs the actual React surfaces in a 1440px default-light desktop and 320px dark English left-to-right layout. It browses all 73 state pages without page errors or document overflow; tests native forms, exact account/media identity, mounted drafts, permissions, filters, evidence disclosure and payload gating; and exercises each flow's primary and consequential recovery paths. It checks fixed templates, hierarchy, search, focus return, hidden sidebar scrollbars, source links and text enlargement. Root font size 200% was used in the initial gate, distinct from page zoom; 0.3.1 replaces this limited check with verified actual font doubling. See [the runnable browser gate](BROWSER-TESTING.md).

The first broad browser run caught long status text overflowing PublishingAgenda; the shared Badge wrapping rule fixes the root cause. Fresh independent source review caught prompt draft saving bypassing a collecting/uncertain execution lock. The repaired D16 Playwright case passes for both states; temporarily removing the guard fails its disabled-action assertion. Stale prior receipts are also hidden during a new D12/D16 quote review. Test authors' local simulations are not independent provider truth; native app contracts, primary references and app-session regression checks provide separate evidence. No live paid/provider operation was used to validate these local flows.

The immutable MIT archive handed to both app owners has SHA256 `F73229FC6B2C7E14348A1DC77709D60E7110756D8EA5B4DA30BE5047BA05033F`. It contains modules, declarations, `product.css`, notices, license and documentation. Both owners verified and pinned it. Consumer adapter acceptance is tracked in [the completion ledger](CAMPAIGN-DISCOVER-COMPLETION.md), independently of the library gate. The public source documentation and browser tests continue to record final review findings; the handed-off archive is never replaced in place.

## Component catalogue

The reference documents every public component export: 38 main components and seven existing-app adapters. `npm run check` runs 23 native checks, including catalogue inventory/link integrity, rendering all 204 state specimens, compiling all 256 standalone TSX examples against the public declarations, URL/search behavior and token/alias references against shipped CSS. The TSX check includes component examples, state examples, three flow recipes, the getting-started form, the Campaign brand/login compositions and token usage. Flow recipes copy the exact rendered source with public imports.

Browser checks cover copy feedback and copied TSX, search by task, global search navigation, typed confirmation guards and rejected actions, table search/sort/pagination, and live token values (38px comfortable, 32px compact; dark surface values). The isolated Campaign login form validates and submits locally; owner setup is available as a separate reference state. Local specimen anchors focus their own targets, and the catalogue skip link keeps the current route while focusing the main content.

All three flow recipe pages also fit a 320px viewport without page-wide horizontal overflow. The real catalogue was measured inside 320px, 360px, 760px and 1440px browser viewports with no page-wide horizontal overflow. Narrow views expose a drawer with inert background and Escape dismissal. LTR/RTL checks at 320px and 360px retain the same document width. The component rail is scrollable with computed `scrollbar-width: none`. These checks are representative acceptance evidence; screen-reader, forced-colors and complete consuming-app route coverage remain outside this validation.

## Shared flow recipes

Run the catalogue, open `/tests/flow-recipes.html` and choose **Run checks**. This native browser regression check mounts the actual React recipes and reports PASS/FAIL. It verifies connection required validation, configured/unverified status, failed verification preserving input, successful synthetic evidence and historical evidence after edits; measured zero versus unavailable; failed refresh retaining the prior result, applied dates and draft dates; filtered-empty recovery; review cancellation preserving a draft; stable focus after confirmation; unknown outcomes without blind retry; inconclusive reconciliation; and a reviewed retry only after confirmed not-applied.

The fixture passed against the final source. A separate fresh-context review found the confirmation focus loss; retaining the same action button across the pending transition corrected it, and the fixture now asserts focus restoration. No backend, provider, physical device or product mutation is exercised by these local simulations.

## Sidebar patch 0.2.2

Both shared sidebar APIs retain `overflow-y: auto` and hide their visible scrollbar using standard `scrollbar-width: none` plus the WebKit pseudo-element. Catalogue navigation uses the same behavior. Version 0.2.2 includes the prior ResourceCard fix; the 0.2.1 archive remains unchanged. The full build and 23 native checks pass. Native browser specimens with 80 menu links confirm both APIs have computed `scrollbar-width: none`, retain `overflow-y: auto`, and scroll to the final links through keyboard focus.

## ResourceCard patch 0.2.1

The patch changes only ResourceCard status wrapping; its API is unchanged. The icon retains its dimensions, the status row can wrap, and long badges remain fully readable. All 18 library checks pass. The real component and stylesheet pass the native browser fixture at a 320px iframe viewport with body zoom 2 in LTR and RTL, including “Events received”, “Waiting for events”, “Check unavailable” and an unbroken identifier. Restoring the original nowrap rules fails the same fixture with document and status overflow.

Run the catalogue and open `/tests/resource-card.html?zoom=2&dir=ltr` or `dir=rtl` at 320px. The page reports PASS/FAIL. `&baseline=1` restores the original layout as a regression control. Consumer app acceptance remains owned by the app session.

## Initial application adoption 0.2.0

Validated locally on 19 October 2026 using Node.js 22.14 for the library and Node.js 24.19 for consuming applications, with React 19.2.8.

Run `npm run check` for TypeScript checking, the library and catalog production builds, and the native Node tests. The original 18 library tests cover table transformations, field associations, confirmation prerequisites, permission role edge cases, secret labels, date boundaries, chart numeric ranges, semantic palette contrast, standalone sizing/fonts, theme and density resets, package exports, retained client directives, native application field defaults/constraints, brand markup and the Campaign inbox icon.

The catalog was also exercised in the browser:

- Table search, natural sorting, pagination, and selection across pages.
- Arrow-key tabs; dialog submission, Escape/close paths and focus restoration.
- Global search, component filtering, all documentation pages and product recipes.
- Light/dark appearance and measured input heights of 38px comfortable and 32px compact.
- Mobile navigation and no page-wide horizontal overflow at 360px; tablet layout at 760px and desktop at the browser's normal width.
- Secret visibility, clipboard success feedback, controlled permission changes and toast feedback.
- Confirmation disabled before exact text entry, enabled afterward, and closing disabled while pending.
- Native date entry rejecting a start date after the end date.

`npm pack` produces `ten98-ui-0.2.0.tgz`, including emitted modules, declarations, CSS, license, retained third-party notices and documentation. Both consuming applications pin the same archive in `vendor`, together with their lockfiles. Their Dockerfiles copy it before dependency installation.

The Campaign and Discover migrations were checked in isolated copies of the current working sources, preserving their in-progress application changes:

- Campaign: TypeScript, production build and all 531 native tests passed.
- Discover: TypeScript, production build, plan checks and 895 native tests passed; three platform-dependent checks were skipped on Windows (FIFO, environment-file symlink and host Docker helper).
- Browser comparison: representative native fields, buttons, tables, status, empty states and authentication headings retained baseline layout and typography at 360px, 760px and 1440px in light and dark contexts. All 100 existing Discover custom properties, including the 85-token public contract, matched the original computed values in both themes.
- Native required validation blocked an empty project name. Edited text, a decimal budget, multiline text and a changed select value submitted through `FormData` correctly. The Discover dark RTL specimen also rendered with native form controls.
- Independent source review found a missing Campaign inbox icon and a nonsplit authentication heading cascade change; both were corrected before application.

These browser comparisons used synthetic markup with the actual application styles and shared components. They do not establish complete route, provider or production service coverage. No database/provider integration suite or live publishing operation was run. Container build inputs were checked; Docker images were not built here.

The catalog build is a browser application and may report that bundled `use client` directives are removed. The installable library uses a separate module build; its emitted client boundaries are checked directly by the test suite.

React 18.3 is included in the declared peer range based on the APIs used; local runtime verification used React 19. Discover's TanStack application was typechecked and built with the shared package. Next.js adoption is documented, but a complete Next.js application was not built here. These checks do not certify accessibility or domain behavior.
