# Browser regression gate

Playwright is a development dependency. Install its official Chromium once, then run:

```sh
npm ci
npx playwright install chromium
npm run check:all
```

`npm run test:browser` runs only the browser suite; `npx playwright test --ui` opens its development runner. The configuration starts the catalogue when needed, or reuses the local server on port 5198 outside CI. It caps concurrency at two workers, disables retries, and retains screenshots/traces on failures. `playwright-report/index.html` is the local report. `npx playwright show-trace <path>` opens a failure trace.

The suite tests real rendered React at desktop and 320px dark RTL. It browses every component's state page, checks page reflow, exercises shared controlled-state invariants, and covers each Campaign C1–C8 and Discover D1–D17 flow. Separate checks cover hierarchy, templates, copyable source, focus return and 200% text reflow. Native regression fixtures are retained for focused component and cross-product interactions.

When running bounded workers concurrently, give each invocation a distinct output folder and disable the shared HTML reporter: `npx playwright test <owned-spec> --output=.qa/<worker> --reporter=line`. Otherwise one process can delete another's trace artifacts. The final release gate runs the complete suite in one process.

For every new component or flow: add or extend its meaningful browser case, verify the primary interaction and its consequential failure/recovery boundary, then run its owned spec before the full gate. Keep test assertions independent of cosmetic implementation. A browser test with synthetic data does not establish provider acceptance, complete accessibility compliance or real consumer integration; app sessions run their own actual application checks.
